$LOAD_PATH.unshift File.dirname(__FILE__)

require 'scorched_earth/version'
require 'scorched_earth/game'
require 'scorched_earth/game_window'

module ScorchedEarth; end
