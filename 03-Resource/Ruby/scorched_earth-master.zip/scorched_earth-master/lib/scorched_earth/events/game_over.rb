module ScorchedEarth
  module Events
    GameOver = Struct.new(:time)
  end
end
