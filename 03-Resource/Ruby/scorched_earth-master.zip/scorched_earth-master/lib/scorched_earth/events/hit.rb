module ScorchedEarth
  module Events
    Hit = Struct.new(:object, :radius)
  end
end
