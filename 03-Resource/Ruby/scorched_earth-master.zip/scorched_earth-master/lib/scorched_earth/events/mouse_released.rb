module ScorchedEarth
  module Events
    MouseReleased = Struct.new(:x, :y)
  end
end
