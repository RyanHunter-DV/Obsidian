module ScorchedEarth
  module Events
    GameUpdate = Struct.new(:delta)
  end
end
