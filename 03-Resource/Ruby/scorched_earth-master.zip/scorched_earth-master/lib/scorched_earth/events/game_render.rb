module ScorchedEarth
  module Events
    GameRender = Struct.new(:graphics)
  end
end
