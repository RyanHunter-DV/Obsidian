module ScorchedEarth
  module Events
    MouseMoved = Struct.new(:x, :y)
  end
end
