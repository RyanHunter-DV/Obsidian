module ScorchedEarth
  module Events
    MousePressed = Struct.new(:x, :y)
  end
end
