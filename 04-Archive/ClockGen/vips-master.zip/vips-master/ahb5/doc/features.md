# protocol check
To check the protocol behaviors, which will be added in the `rhAhb5If.sv`, named as `rhAhb5ProtocolCheck.sva`, that directly included by the interface file.

#BLOCKED, need protocol study.
