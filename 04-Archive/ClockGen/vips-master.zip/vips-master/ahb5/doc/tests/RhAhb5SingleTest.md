base: [[RhAhb5BaseTest]]

# attributes


# methods

`# testConfig`
- set eConfig.slaveReadyDelay(0,100);
- set eConfig.slaveResponseMode("random");
- set eConfig.protocolCheck(1);

