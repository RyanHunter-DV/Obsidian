**field**
```systemverilog
typedef enum {
	QExit,
	QStopped,
	QRun,
	QRequest,
	QDenied,
	QContinue
} RhQLpiState;

```