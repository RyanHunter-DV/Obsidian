**object** `RhQLpiConfig`
**field**
```
// TODO
```

# Public APIs
**func** `void enableAutoPowerUp(int min, int max)`
```systemverilog
// TODO
```

**func** `void disableAutoPowerUp()`