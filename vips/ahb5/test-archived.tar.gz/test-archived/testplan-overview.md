# master device test
Establish a verification environment and cases to verify the master devices, using C++ programming language.
[[vips/ahb5/test/testplan-master]]

# slave device test